
import './App.css';

import Statistics from "./components/Statistics";
import Testimonial from './components/Testimonial';
function App(){
  return(
    <><Statistics/><Testimonial/></>
  )
}
export default App